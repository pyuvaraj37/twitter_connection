Twitter Connection

A python library that allows users to interface with Twitters API, specifically the standard API.
This does not utilize the Enterprise or Premium functionality. 

```bash
python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps twitter_connection
```