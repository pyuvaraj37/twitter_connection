
def search():
    return 'https://api.twitter.com/1.1/search/tweets.json?'