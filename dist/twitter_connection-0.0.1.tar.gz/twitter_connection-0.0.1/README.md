Twitter Connection

A python library that allows users to interface with Twitters API, specifically the standard API.
This does not utilize the Enterprise or Premium functionality. 